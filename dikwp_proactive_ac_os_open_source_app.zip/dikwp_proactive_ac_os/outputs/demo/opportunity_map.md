# Opportunity Map

Route: **launch_proactive_ac_lab**

## Strongest initiative routes

- propose_learning_sprint: 1
- propose_research_ledger: 1
- propose_workflow_refactor: 1
- propose_public_value_project: 1
- human_review_required: 1

## Next move

Start a reversible 14-day ProactiveAC lab with consent logging, daily residual review, and no external automation.
