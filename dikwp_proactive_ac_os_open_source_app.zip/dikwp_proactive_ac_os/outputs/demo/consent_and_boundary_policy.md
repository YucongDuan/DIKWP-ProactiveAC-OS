# Consent and Boundary Policy

No external action without explicit consent. No credential capture. No hidden monitoring. No subjective consciousness claims.
