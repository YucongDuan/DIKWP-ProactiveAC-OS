# Learning Accumulation Plan

Week 1: Build the human-nature map and evidence ledger.

Week 2: Run DIKWP collapse on repeated observations.

Week 3: Convert high-quality collapse outputs into initiative tickets.

Week 4: Review consent, rollback, residuals and actual outcomes.
