import argparse
import json
from pathlib import Path

from .analyzer import analyze_case, load_case, run_guard, write_outputs
from .static_audit import audit_path


def main() -> None:
    parser = argparse.ArgumentParser(prog="proactive-ac")
    sub = parser.add_subparsers(dest="cmd", required=True)

    analyze = sub.add_parser("analyze")
    analyze.add_argument("case")
    analyze.add_argument("--out", default="outputs/demo")

    guard = sub.add_parser("guard")
    guard.add_argument("text")

    audit = sub.add_parser("static-audit")
    audit.add_argument("path")
    audit.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")

    args = parser.parse_args()
    if args.cmd == "analyze":
        case = load_case(args.case)
        report = analyze_case(case)
        write_outputs(report, args.out)
        print(json.dumps({
            "case_id": report["case_id"],
            "route": report["route"],
            "proactive_ac_index": report["proactive_ac_index"],
            "ticket_count": report["ticket_count"]
        }, ensure_ascii=False, indent=2))
    elif args.cmd == "guard":
        print(json.dumps(run_guard(args.text), ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        result = audit_path(args.path)
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
