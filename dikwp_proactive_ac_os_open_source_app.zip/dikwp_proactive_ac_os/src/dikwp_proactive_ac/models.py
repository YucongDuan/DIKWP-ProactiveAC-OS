from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class HumanNatureSignal:
    name: str
    intensity: float
    evidence_refs: List[str] = field(default_factory=list)
    notes: str = ""


@dataclass
class Observation:
    id: str
    text: str
    domain: str
    evidence_refs: List[str] = field(default_factory=list)
    urgency: float = 0.0
    uncertainty: float = 0.5


@dataclass
class IntentContract:
    goal: str
    value: str
    constraints: List[str]
    time_window: str
    feedback_plan: str


@dataclass
class UserCase:
    case_id: str
    title: str
    subject_type: str
    intent: IntentContract
    observations: List[Observation]
    human_nature_signals: List[HumanNatureSignal]
    evidence: List[Dict[str, Any]] = field(default_factory=list)
    allowed_scopes: List[str] = field(default_factory=list)
    forbidden_actions: List[str] = field(default_factory=list)


@dataclass
class InitiativeTicket:
    ticket_id: str
    title: str
    route: str
    priority: str
    autonomy_level: str
    action: str
    evidence_refs: List[str]
    consent_required: bool
    rollback_plan: str
    kill_conditions: List[str]


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))
