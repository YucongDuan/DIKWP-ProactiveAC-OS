from pathlib import Path
from typing import Dict, List

PROHIBITED_PATTERNS = [
    "import requests", "from requests", "import urllib", "from urllib", "import socket",
    "import subprocess", "from subprocess", "os.system", "eval(", "exec(",
    "session cookie", "api key capture", "password capture", "selenium", "playwright"
]


def audit_path(path: str) -> Dict[str, object]:
    root = Path(path)
    findings: List[Dict[str, str]] = []
    for file in root.rglob("*.py"):
        if file.name in {"static_audit.py", "guard.py"}:
            continue
        text = file.read_text(encoding="utf-8", errors="ignore").lower()
        for pat in PROHIBITED_PATTERNS:
            if pat.lower() in text:
                findings.append({"file": str(file), "pattern": pat})
    return {
        "policy": "No network imports, subprocess, dynamic execution, credential capture, hidden telemetry, browser automation, host mutation, or unconsented external action in offline core.",
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings
    }
