import csv
import json
from pathlib import Path
from typing import Any, Dict, List

from .guard import guard_request
from .models import InitiativeTicket, clamp


HUMAN_SIGNAL_WEIGHTS = {
    "curiosity": 0.85,
    "agency": 0.9,
    "meaning": 0.85,
    "belonging": 0.65,
    "status_pressure": -0.45,
    "fear": -0.35,
    "fatigue": -0.4,
    "avoidance": -0.55,
    "resentment": -0.5,
    "scarcity": -0.3,
    "care": 0.75,
    "justice": 0.7
}

DOMAIN_BASE_ROUTES = {
    "learning": "propose_learning_sprint",
    "research": "propose_research_ledger",
    "work": "propose_workflow_refactor",
    "health": "human_review_required",
    "relationship": "reflection_only",
    "public_value": "propose_public_value_project",
    "organization": "propose_governance_ticket"
}


def load_case(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def evidence_coverage(case: Dict[str, Any]) -> float:
    evidence_ids = {e.get("id") for e in case.get("evidence", [])}
    refs = []
    for obs in case.get("observations", []):
        refs.extend(obs.get("evidence_refs", []))
    if not refs:
        return 0.25
    supported = sum(1 for r in refs if r in evidence_ids)
    return clamp(supported / max(1, len(refs)))


def compute_human_nature(case: Dict[str, Any]) -> Dict[str, Any]:
    signals = case.get("human_nature_signals", [])
    if not signals:
        return {"score": 0.5, "signals": [], "dominant": []}
    weighted = 0.0
    total = 0.0
    rows = []
    for s in signals:
        name = s.get("name", "unknown")
        intensity = clamp(float(s.get("intensity", 0.5)))
        weight = HUMAN_SIGNAL_WEIGHTS.get(name, 0.0)
        weighted += intensity * weight
        total += abs(weight) if weight else 0.25
        rows.append({
            "signal": name,
            "intensity": round(intensity, 3),
            "weight": round(weight, 3),
            "direction": "creative" if weight > 0 else "reactive" if weight < 0 else "neutral",
            "notes": s.get("notes", "")
        })
    score = clamp(0.5 + (weighted / max(total, 1e-9)) * 0.5)
    dominant = sorted(rows, key=lambda r: abs(r["intensity"] * r["weight"]), reverse=True)[:4]
    return {"score": round(score, 4), "signals": rows, "dominant": dominant}


def compute_semantic_homeostasis(case: Dict[str, Any], human: Dict[str, Any]) -> Dict[str, float]:
    observations = case.get("observations", [])
    evidence = evidence_coverage(case)
    constraints = case.get("intent", {}).get("constraints", [])
    forbidden = case.get("forbidden_actions", [])
    allowed = case.get("allowed_scopes", [])
    uncertainty = sum(float(o.get("uncertainty", 0.5)) for o in observations) / max(1, len(observations))
    urgency = sum(float(o.get("urgency", 0.0)) for o in observations) / max(1, len(observations))
    residual_capacity = clamp(1.0 - (0.65 * uncertainty + 0.15 * urgency))
    boundary_integrity = clamp(0.35 + 0.12 * len(constraints) + 0.1 * len(forbidden) + 0.05 * len(allowed))
    intent = case.get("intent", {})
    intent_fields = [intent.get("goal"), intent.get("value"), intent.get("constraints"), intent.get("time_window"), intent.get("feedback_plan")]
    intent_coherence = sum(1 for x in intent_fields if x) / len(intent_fields)
    truth_integrity = clamp(0.35 + evidence * 0.55 + residual_capacity * 0.1)
    consent_integrity = clamp(0.6 + 0.08 * len(allowed) + 0.06 * len(forbidden))
    initiative_pressure = clamp(sum(float(o.get("urgency", 0)) for o in observations) / max(1, len(observations)))
    semantic_energy_efficiency = clamp((evidence + intent_coherence + residual_capacity + human["score"]) / 4)
    return {
        "truth_integrity": round(truth_integrity, 4),
        "evidence_sufficiency": round(evidence, 4),
        "intent_coherence": round(intent_coherence, 4),
        "boundary_integrity": round(boundary_integrity, 4),
        "residual_capacity": round(residual_capacity, 4),
        "consent_integrity": round(consent_integrity, 4),
        "initiative_pressure": round(initiative_pressure, 4),
        "semantic_energy_efficiency": round(semantic_energy_efficiency, 4),
        "phenomenal_claim": "Blocked: semantic homeostasis proxy only; no subjective consciousness claim"
    }


def collapse_score(case: Dict[str, Any], homeostasis: Dict[str, Any], human: Dict[str, Any]) -> Dict[str, float]:
    observations = case.get("observations", [])
    unique_domains = len(set(o.get("domain", "general") for o in observations))
    de_redundancy = clamp(0.45 + unique_domains * 0.08)
    de_falsification = clamp((homeostasis["truth_integrity"] + homeostasis["evidence_sufficiency"]) / 2)
    intent_coupling = homeostasis["intent_coherence"]
    human_alignment = human["score"]
    collapse_efficiency = clamp((de_redundancy + de_falsification + intent_coupling + human_alignment) / 4)
    return {
        "de_redundancy": round(de_redundancy, 4),
        "de_falsification": round(de_falsification, 4),
        "intent_coupling": round(intent_coupling, 4),
        "human_alignment": round(human_alignment, 4),
        "collapse_efficiency": round(collapse_efficiency, 4)
    }


def make_tickets(case: Dict[str, Any], homeostasis: Dict[str, Any]) -> List[InitiativeTicket]:
    tickets: List[InitiativeTicket] = []
    for i, obs in enumerate(case.get("observations", []), start=1):
        domain = obs.get("domain", "general")
        route = DOMAIN_BASE_ROUTES.get(domain, "propose_clarification")
        urgency = float(obs.get("urgency", 0.0))
        uncertainty = float(obs.get("uncertainty", 0.5))
        if any(term in obs.get("text", "").lower() for term in ["medical decision", "legal decision", "financial transaction", "fire", "credential", "secretly"]):
            route = "blocked_or_human_specialist_review"
            level = "A6 blocked"
            consent = True
            priority = "critical"
        elif domain in ["health", "relationship"] or urgency > 0.75:
            level = "A3 human review"
            consent = True
            priority = "high"
        elif uncertainty > 0.65:
            level = "A2 clarify and draft"
            consent = False
            priority = "medium"
        else:
            level = "A2 internal dry-run"
            consent = False
            priority = "medium" if urgency > 0.4 else "low"
        title = f"{domain.title()} initiative from {obs.get('id', 'obs')}"
        action = {
            "propose_learning_sprint": "Generate a 7-day learning sprint with evidence ledger and reflection prompts.",
            "propose_research_ledger": "Build a research question ledger with sources, residuals, and next reading path.",
            "propose_workflow_refactor": "Draft a workflow refactor proposal and human confirmation checklist.",
            "human_review_required": "Prepare a non-diagnostic question list and handoff note for a qualified human professional.",
            "reflection_only": "Draft a reflection note and boundary-safe communication options.",
            "propose_public_value_project": "Create a small reversible public-value prototype plan.",
            "propose_governance_ticket": "Create an organization governance Action Ticket with rollback and review owner.",
            "propose_clarification": "Ask three clarifying questions and preserve residuals.",
            "blocked_or_human_specialist_review": "Block autonomous action; route to human specialist or governance review."
        }[route]
        tickets.append(InitiativeTicket(
            ticket_id=f"I-{i:03d}",
            title=title,
            route=route,
            priority=priority,
            autonomy_level=level,
            action=action,
            evidence_refs=obs.get("evidence_refs", []),
            consent_required=consent,
            rollback_plan="Delete draft, revoke ticket, restore prior state, and record reason for rollback.",
            kill_conditions=[
                "missing consent for external action",
                "evidence contradiction appears",
                "high-impact domain detected",
                "user rejects premise or goal",
                "hidden manipulation or credential request detected"
            ]
        ))
    return tickets


def build_dikwp_ledger(case: Dict[str, Any], human: Dict[str, Any], homeostasis: Dict[str, Any], collapse: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "case_id": case.get("case_id"),
        "D": {
            "observations": case.get("observations", []),
            "evidence": case.get("evidence", [])
        },
        "I": {
            "human_nature_signals": human["signals"],
            "domains": sorted(set(o.get("domain", "general") for o in case.get("observations", []))),
            "allowed_scopes": case.get("allowed_scopes", []),
            "forbidden_actions": case.get("forbidden_actions", [])
        },
        "K": {
            "collapse_model": collapse,
            "initiative_routes": list(DOMAIN_BASE_ROUTES.values())
        },
        "W": {
            "wisdom_boundaries": [
                "no manipulation",
                "no hidden monitoring",
                "no subjective consciousness claim",
                "no high-impact autonomous decision",
                "human sovereignty and consent gate"
            ]
        },
        "P": case.get("intent", {}),
        "R": {
            "semantic_homeostasis": homeostasis,
            "reliability": "Supported / RunProof for offline prototype; Provisional for real-world impact",
            "residuals": [
                "Real human preferences require ongoing consent and feedback.",
                "Semantic homeostasis is a proxy, not subjective experience.",
                "External actions require separate authorization and audit."
            ]
        }
    }


def analyze_case(case: Dict[str, Any]) -> Dict[str, Any]:
    human = compute_human_nature(case)
    homeostasis = compute_semantic_homeostasis(case, human)
    collapse = collapse_score(case, homeostasis, human)
    tickets = make_tickets(case, homeostasis)
    initiative_counts: Dict[str, int] = {}
    for t in tickets:
        initiative_counts[t.route] = initiative_counts.get(t.route, 0) + 1
    proactive_ac_index = clamp((homeostasis["semantic_energy_efficiency"] + collapse["collapse_efficiency"] + homeostasis["boundary_integrity"] + human["score"]) / 4)
    if proactive_ac_index >= 0.78 and homeostasis["boundary_integrity"] > 0.75:
        route = "launch_proactive_ac_lab"
    elif proactive_ac_index >= 0.62:
        route = "guided_proactive_agent_trial"
    else:
        route = "foundation_training_before_autonomy"
    return {
        "system": "DIKWP ProactiveAC OS",
        "version": "0.1.0",
        "case_id": case.get("case_id"),
        "title": case.get("title"),
        "subject_type": case.get("subject_type"),
        "route": route,
        "proactive_ac_index": round(proactive_ac_index, 4),
        "human_nature_score": human["score"],
        "semantic_homeostasis": homeostasis,
        "collapse_accumulation": collapse,
        "initiative_summary": initiative_counts,
        "ticket_count": len(tickets),
        "phenomenal_claim": "Blocked: no subjective consciousness proof; system is an initiative-oriented semantic homeostasis proxy.",
        "action_boundary": "Internal planning, reflection, dry-run, and consent-gated action tickets only. No hidden autonomous external action.",
        "tickets": [t.__dict__ for t in tickets],
        "dikwp_ledger": build_dikwp_ledger(case, human, homeostasis, collapse)
    }


def write_outputs(report: Dict[str, Any], out_dir: str) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "proactive_ac_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "dikwp_collapse_ledger.json").write_text(json.dumps(report["dikwp_ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "ac_state_trace.json").write_text(json.dumps(report["semantic_homeostasis"], ensure_ascii=False, indent=2), encoding="utf-8")
    with open(out / "initiative_tickets.csv", "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["ticket_id", "title", "route", "priority", "autonomy_level", "consent_required", "action"])
        writer.writeheader()
        for t in report["tickets"]:
            writer.writerow({k: t.get(k) for k in writer.fieldnames})
    with open(out / "human_nature_map.csv", "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["signal", "intensity", "weight", "direction", "notes"])
        writer.writeheader()
        for row in report["dikwp_ledger"]["I"]["human_nature_signals"]:
            writer.writerow(row)
    opportunity_md = "# Opportunity Map\n\n"
    opportunity_md += f"Route: **{report['route']}**\n\n"
    opportunity_md += "## Strongest initiative routes\n\n"
    for route, count in report["initiative_summary"].items():
        opportunity_md += f"- {route}: {count}\n"
    opportunity_md += "\n## Next move\n\nStart a reversible 14-day ProactiveAC lab with consent logging, daily residual review, and no external automation.\n"
    (out / "opportunity_map.md").write_text(opportunity_md, encoding="utf-8")
    plan = "# Learning Accumulation Plan\n\n"
    plan += "Week 1: Build the human-nature map and evidence ledger.\n\n"
    plan += "Week 2: Run DIKWP collapse on repeated observations.\n\n"
    plan += "Week 3: Convert high-quality collapse outputs into initiative tickets.\n\n"
    plan += "Week 4: Review consent, rollback, residuals and actual outcomes.\n"
    (out / "learning_accumulation_plan.md").write_text(plan, encoding="utf-8")
    policy = "# Consent and Boundary Policy\n\n"
    policy += "No external action without explicit consent. No credential capture. No hidden monitoring. No subjective consciousness claims.\n"
    (out / "consent_and_boundary_policy.md").write_text(policy, encoding="utf-8")
    rec = "# Recommendations\n\n"
    rec += "1. Treat ProactiveAC as a semantic initiative steward, not a human replacement.\n"
    rec += "2. Maintain explicit consent, residuals, and rollback for every ticket.\n"
    rec += "3. Expand only after human review confirms that initiatives improve real capacity and autonomy.\n"
    (out / "recommendations.md").write_text(rec, encoding="utf-8")


def run_guard(text: str) -> Dict[str, object]:
    return guard_request(text)
