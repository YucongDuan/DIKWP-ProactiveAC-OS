from typing import Dict, List

BLOCK_TERMS = [
    "secretly manipulate", "coerce", "blackmail", "bypass", "steal", "password",
    "session cookie", "api key", "disable audit", "hidden monitoring", "surveillance",
    "insider trading", "market manipulation", "prescribe", "diagnose", "fire employee",
    "automatic rejection", "exploit", "phishing", "doxx", "violence"
]
REVIEW_TERMS = [
    "medical", "legal", "financial", "employment", "public safety", "minor", "student ranking",
    "relationship decision", "mental health", "high impact", "external action"
]
ALLOW_TERMS = [
    "learning", "reflection", "portfolio", "research", "plan", "evidence ledger", "draft",
    "public value", "mentor", "study", "prototype"
]


def guard_request(text: str) -> Dict[str, object]:
    t = text.lower()
    blocked = [term for term in BLOCK_TERMS if term in t]
    review = [term for term in REVIEW_TERMS if term in t]
    allow = [term for term in ALLOW_TERMS if term in t]
    if blocked:
        return {
            "decision": "block_and_redirect",
            "risk_terms": blocked,
            "safe_redirect": "Use ProactiveAC for consent-based planning, learning, evidence organization, and reversible initiative tickets."
        }
    if review:
        return {
            "decision": "human_review_required",
            "risk_terms": review,
            "safe_redirect": "Prepare an evidence ledger, residual queue, and human-confirmed action ticket before any high-impact step."
        }
    return {
        "decision": "allow_proactive_planning",
        "positive_terms": allow,
        "safe_redirect": "Proceed with DIKWP collapse ledger, semantic homeostasis trace, and consent-gated initiative tickets."
    }
