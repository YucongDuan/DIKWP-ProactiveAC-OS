# Human Nature Model

The system treats human nature as a mixed field of creative and reactive forces.

Creative signals include curiosity, agency, meaning, care, justice and belonging. Reactive signals include fear, fatigue, avoidance, scarcity pressure, status pressure and resentment. The purpose is not to manipulate these signals, but to help the user notice which signals are driving a decision and whether they are creating capacity or degrading autonomy.
