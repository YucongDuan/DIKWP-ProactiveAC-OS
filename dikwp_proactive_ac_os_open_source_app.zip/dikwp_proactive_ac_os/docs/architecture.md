# Architecture

DIKWP ProactiveAC OS has five layers:

1. Human Nature Map: curiosity, fear, agency, fatigue, belonging, status pressure, care, justice and avoidance.
2. DIKWP Collapse Accumulator: converts repeated observations into D/I/K/W/P/R semantic units.
3. Semantic Homeostasis Core: tracks truth integrity, evidence sufficiency, intent coherence, boundary integrity, residual capacity and consent integrity.
4. Initiative Engine: generates proactive Action Tickets.
5. Consent and Boundary Gate: prevents unconsented external action and high-impact automation.

The system is offline-first and intentionally avoids network calls, credential capture, hidden telemetry, browser automation, and high-impact autonomous action.
