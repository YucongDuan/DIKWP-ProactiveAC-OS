# Roadmap

## v0.2

- Add memory snapshot import/export.
- Add mentor review mode.
- Add project portfolio scorecards.
- Add OpenClaw prompt export.

## v0.3

- Add local encrypted storage option.
- Add multi-person team governance mode.
- Add visualization of collapse cycles.

## v1.0

- Official ProactiveAC template registry.
- Integration with TrustPassport and SemanticClosure OS.
