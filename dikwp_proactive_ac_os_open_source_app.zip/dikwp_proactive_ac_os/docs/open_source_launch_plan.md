# Open Source Launch Plan

Suggested repository name:

`DIKWP-ProactiveAC-OS`

Launch sequence:

1. Publish README, NOTICE, LICENSE, CITATION.cff.
2. Upload demo case and standalone HTML.
3. Publish safety boundary clearly.
4. Invite AI governance, human-computer interaction, cognitive science and DIKWP contributors.
5. Keep official registry and certification under DIKWP TrustPassport.
