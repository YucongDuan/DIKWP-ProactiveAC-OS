# Governance Boundary

Use for:

- learning planning
- research planning
- self-reflection
- internal dry-run drafts
- public-value project ideation
- organization governance prototyping

Do not use for:

- manipulation
- credential capture
- hidden surveillance
- clinical, legal, financial, employment or public safety decisions
- external action without consent
- claims of subjective consciousness
