# Semantic Homeostasis Core

The semantic homeostasis core tracks:

- truth_integrity;
- evidence_sufficiency;
- intent_coherence;
- boundary_integrity;
- residual_capacity;
- human_nature_awareness;
- proactive_readiness.

This is a proxy. It does not prove subjective experience, sentience, or artificial life.
