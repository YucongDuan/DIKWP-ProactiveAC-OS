# User Manual

## Browser Demo

Open `index.html`.

Use the demo to inspect:

- semantic homeostasis;
- human-nature signals;
- proactive opportunities;
- action tickets;
- consent boundary;
- phenomenal residual.

## CLI

```bash
proactive-ac analyze examples/sample_proactive_ac_case.json --out outputs/demo
proactive-ac guard "your request"
proactive-ac static-audit src --out outputs/demo/static_boundary_audit_report.json
```
