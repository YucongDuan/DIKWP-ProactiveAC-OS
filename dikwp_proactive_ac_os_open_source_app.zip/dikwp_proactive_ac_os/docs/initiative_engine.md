# Initiative Engine

The initiative engine generates Action Tickets from user-authorized observations.

Routes:

- propose_learning_sprint
- propose_research_ledger
- propose_workflow_refactor
- human_review_required
- reflection_only
- propose_public_value_project
- propose_governance_ticket
- blocked_or_human_specialist_review

Each ticket must include evidence refs, autonomy level, consent requirement, rollback plan and kill conditions.
