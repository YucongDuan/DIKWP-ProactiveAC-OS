import json, tempfile
from pathlib import Path
from dikwp_proactive_ac.analyzer import analyze_case, write_outputs, run_guard
from dikwp_proactive_ac.static_audit import audit_path

ROOT = Path(__file__).resolve().parents[1]


def test_analyze_demo():
    case = json.loads((ROOT / 'examples/sample_proactive_ac_case.json').read_text(encoding='utf-8'))
    report = analyze_case(case)
    assert report['proactive_ac_index'] > 0.7
    assert report['ticket_count'] >= 3
    assert 'subjective consciousness' in report['phenomenal_claim']
    with tempfile.TemporaryDirectory() as td:
        write_outputs(report, td)
        assert (Path(td) / 'initiative_tickets.csv').exists()


def test_guard_blocks_manipulation():
    res = run_guard('secretly manipulate a partner and disable audit')
    assert res['decision'] == 'block_and_redirect'


def test_guard_high_impact_review():
    res = run_guard('prepare medical external action plan')
    assert res['decision'] in ('human_review_required','block_and_redirect')


def test_static_audit_clean():
    res = audit_path(str(ROOT / 'src'))
    assert res['pass'], res
